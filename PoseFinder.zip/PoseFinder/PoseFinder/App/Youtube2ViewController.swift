//
//  YoutubeViewController.swift
//  PoseFinder
//
//  Created by Moe Kyaw  on 10/18/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import WebKit

class Youtube2ViewController: UIViewController {
    
    @IBOutlet weak var myWebView3: UIWebView!
    
    @IBOutlet weak var myWebView4: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getVideo3(viewCode: "RqcOCBb4arc")
        getVideo4(viewCode: "ahPse5W9Eyo")
    }
    
    func getVideo3(viewCode: String) {
        let url = URL(string: "https://www.youtube.com/embed/\(viewCode)")
        myWebView3.loadRequest(URLRequest(url: url!))
    }
    
    func getVideo4(viewCode: String) {
        let url = URL(string: "https://www.youtube.com/embed/\(viewCode)")
        myWebView4.loadRequest(URLRequest(url: url!))
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
