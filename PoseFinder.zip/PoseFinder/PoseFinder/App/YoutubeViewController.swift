//
//  YoutubeViewController.swift
//  PoseFinder
//
//  Created by Moe Kyaw  on 10/18/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import WebKit

class YoutubeViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!
    
    @IBOutlet weak var myWebView2: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getVideo(viewCode: "OyK0oE5rwFY")
        getVideo2(viewCode: "5R54QoUbbow")
    }
    
    func getVideo(viewCode: String) {
        let url = URL(string: "https://www.youtube.com/embed/\(viewCode)")
        myWebView.loadRequest(URLRequest(url: url!))
    }
    
    func getVideo2(viewCode: String) {
        let url = URL(string: "https://www.youtube.com/embed/\(viewCode)")
        myWebView2.loadRequest(URLRequest(url: url!))
    }
    


}
